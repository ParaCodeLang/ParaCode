class LogColour():
    Default = "\033[0m"
    Error = "\033[31;1m"
    Warning = "\033[33m"
    Info = "\033[34m"
    Bold = "\033[1m"

