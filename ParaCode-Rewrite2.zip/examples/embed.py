from ParaCode import ParaCode

def example_embed(paraCode):
    paraCode.call_function('print', ["Hello from embed.py!"])